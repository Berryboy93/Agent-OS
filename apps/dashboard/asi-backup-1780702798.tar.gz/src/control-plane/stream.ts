import { QueryClient } from '@tanstack/react-query';
import { ControlPlaneRouter } from './router';
import { ControlEvent } from './events';
import { eventStore } from '../event-store';

let socket: WebSocket | null = null;

export function initControlPlane(queryClient: QueryClient) {
  const router = new ControlPlaneRouter(queryClient);

  if (socket) return;

  const WS_URL =
    import.meta.env.VITE_WS_URL || 'ws://localhost:3000/ws';

  socket = new WebSocket(WS_URL);

  socket.onmessage = (message: MessageEvent) => {
    try {
      const raw = JSON.parse(message.data);

      const controlEvent = normalize(raw);

      if (!controlEvent) return;

      // 1. route to UI cache system
      router.handle(controlEvent);

      // 2. persist to event store (safe logging layer)
      eventStore.append({
        id: crypto.randomUUID(),
        type: controlEvent.type,
        timestamp: Date.now(),

        runId: (controlEvent as any).runId,
        agentId: (controlEvent as any).agentId,
        deploymentId: (controlEvent as any).deploymentId,
        approvalId: (controlEvent as any).approvalId,

        payload: controlEvent,
      });
    } catch (err) {
      console.warn('control-plane stream error', err);
    }
  };

  socket.onclose = () => {
    socket = null;
    setTimeout(() => initControlPlane(queryClient), 3000);
  };
}

/**
 * STRICT NORMALIZER
 */
function normalize(raw: any): ControlEvent | null {
  if (!raw || typeof raw.type !== 'string') return null;

  switch (raw.type) {
    case 'run_created':
      return { type: 'run.started', runId: String(raw.id) };

    case 'run_updated':
      return { type: 'run.updated', runId: String(raw.id) };

    case 'run_completed':
      return { type: 'run.completed', runId: String(raw.id) };

    case 'agent_changed':
      return { type: 'agent.updated', agentId: String(raw.id) };

    case 'approval_changed':
      return { type: 'approval.updated', approvalId: String(raw.id) };

    case 'deployment_changed':
      return { type: 'deployment.updated', deploymentId: String(raw.id) };

    case 'system_health':
      return { type: 'system.health', status: String(raw.status) };

    default:
      return null;
  }
}