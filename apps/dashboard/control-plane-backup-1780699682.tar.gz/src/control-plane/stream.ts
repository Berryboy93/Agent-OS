import { QueryClient } from '@tanstack/react-query';
import { ControlPlaneRouter } from './router';
import { ControlEvent } from './events';

let socket: WebSocket | null = null;

export function initControlPlane(queryClient: QueryClient) {
  const router = new ControlPlaneRouter(queryClient);

  if (socket) return;

  const WS_URL =
    import.meta.env.VITE_WS_URL || 'ws://localhost:3000/ws';

  socket = new WebSocket(WS_URL);

  socket.onmessage = (messageEvent: MessageEvent) => {
    try {
      const raw = JSON.parse(messageEvent.data);

      const controlEvent = normalize(raw);

      if (!controlEvent) return;

      router.handle(controlEvent);
    } catch (e) {
      console.warn('control-plane error', e);
    }
  };

  socket.onclose = () => {
    socket = null;
    setTimeout(() => initControlPlane(queryClient), 3000);
  };
}

/**
 * STRICT NORMALIZER
 * Converts backend events → ControlPlane events
 */
function normalize(raw: any): ControlEvent | null {
  switch (raw?.type) {
    case 'run_created':
      return { type: 'run.started', runId: raw.id };

    case 'run_updated':
      return { type: 'run.updated', runId: raw.id };

    case 'run_completed':
      return { type: 'run.completed', runId: raw.id };

    case 'agent_changed':
      return { type: 'agent.updated', agentId: raw.id };

    case 'approval_changed':
      return { type: 'approval.updated', approvalId: raw.id };

    case 'deployment_changed':
      return { type: 'deployment.updated', deploymentId: raw.id };

    case 'system_health':
      return { type: 'system.health', status: raw.status };

    default:
      return null;
  }
}