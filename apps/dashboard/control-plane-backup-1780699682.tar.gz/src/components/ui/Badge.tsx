import { STATUS_COLOR } from '../../lib/theme'

interface BadgeProps {
  status: string
  variant?: 'solid' | 'outline'
}

export function Badge({ status, variant = 'solid' }: BadgeProps) {
  const color = STATUS_COLOR[status] ?? '#888888'

  return (
    <span
      className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-semibold uppercase tracking-wide ${
        variant === 'outline'
          ? 'border'
          : ''
      }`}
      style={{
        color,
        backgroundColor: variant === 'solid' ? `${color}22` : 'transparent',
        borderColor: variant === 'outline' ? color : undefined,
      }}
    >
      {status}
    </span>
  )
}
