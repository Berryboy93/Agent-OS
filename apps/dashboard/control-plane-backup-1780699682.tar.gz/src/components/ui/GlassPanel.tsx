import { ReactNode } from 'react';

export function GlassPanel({ children, className = '' }: { children: ReactNode; className?: string }) {
  return (
    <div
      className={className}
      style={{
        borderRadius: 16,
        background: 'rgba(255,255,255,0.06)',
        backdropFilter: 'blur(18px)',
        boxShadow: '0 0 0 1px rgba(255,255,255,0.08) inset',
      }}
    >
      {children}
    </div>
  );
}
