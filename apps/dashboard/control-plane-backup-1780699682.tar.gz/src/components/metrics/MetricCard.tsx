import { ReactNode } from 'react';
import { GlassPanel } from '../ui/GlassPanel';

export function MetricCard({ label, value, detail, sparkline }: {
  label: string;
  value: ReactNode;
  detail?: ReactNode;
  sparkline?: ReactNode;
}) {
  return (
    <GlassPanel>
      <div style={{ minHeight: 128, padding: 16, display: 'flex', flexDirection: 'column', gap: 8 }}>
        <div style={{ opacity: 0.7, fontSize: 13 }}>{label}</div>
        <div style={{ fontSize: 30, fontWeight: 700, lineHeight: 1.1 }}>{value}</div>
        {detail && <div style={{ opacity: 0.75, fontSize: 12 }}>{detail}</div>}
        {sparkline && <div style={{ marginTop: 'auto' }}>{sparkline}</div>}
      </div>
    </GlassPanel>
  );
}
