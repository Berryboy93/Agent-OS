import { ReactNode } from 'react';

export function MetricGrid({ children }: { children: ReactNode }) {
  return (
    <section style={{
      display: 'grid',
      gridTemplateColumns: 'repeat(4, minmax(0, 1fr))',
      gap: 16,
    }}>
      {children}
    </section>
  );
}
