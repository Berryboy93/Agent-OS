import { QueryClient } from '@tanstack/react-query';

let socket: WebSocket | null = null;

export function initEventBridge(queryClient: QueryClient) {
  if (socket) return;

  const WS_URL = import.meta.env.VITE_WS_URL || 'ws://localhost:3000/ws';

  socket = new WebSocket(WS_URL);

  socket.onmessage = (event) => {
    try {
      const msg = JSON.parse(event.data);

      const invalidate = (key: any[]) =>
        queryClient.invalidateQueries({ queryKey: key });

      switch (msg.type) {
        case 'health.updated':
          invalidate(['health']);
          break;
        case 'stats.updated':
          invalidate(['stats']);
          break;
        case 'runs.updated':
          invalidate(['runs']);
          break;
        case 'events.new':
          invalidate(['events']);
          break;
        case 'agents.updated':
          invalidate(['agents']);
          break;
        case 'deployments.updated':
          invalidate(['deployments']);
          break;
        case 'approvals.updated':
          invalidate(['approvals']);
          break;
      }
    } catch (e) {
      console.warn('eventBridge error', e);
    }
  };

  socket.onclose = () => {
    socket = null;
    setTimeout(() => initEventBridge(queryClient), 3000);
  };
}
